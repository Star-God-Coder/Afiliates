import { Body, Controller, Post, UseGuards } from '@nestjs/common';
import { CurrentUser, type AuthUser } from '../auth/current-user.decorator';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { CreateOrderDto } from './dto/create-order.dto';
import { OrdersService } from './orders.service';

@Controller('orders')
@UseGuards(JwtAuthGuard)
export class OrdersController {
  constructor(private readonly orders: OrdersService) {}

  @Post()
  async create(@CurrentUser() user: AuthUser, @Body() dto: CreateOrderDto) {
    const order = await this.orders.create(user.id, dto);
    return { id: order.id, totalCents: order.totalCents, status: order.status };
  }

  // Nota: NO expongas markAsPaid/refund como endpoints públicos.
  // Llámalos solo desde el webhook verificado de tu pasarela de pago.
}
