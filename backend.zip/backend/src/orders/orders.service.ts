import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { DataSource, In, Repository } from 'typeorm';
import { AffiliatesService } from '../affiliates/affiliates.service';
import { CommissionsService } from '../affiliates/commissions.service';
import { CreateOrderDto } from './dto/create-order.dto';
import { Order, OrderItem, OrderStatus } from './entities/order.entity';
import { Product } from './entities/product.entity';

@Injectable()
export class OrdersService {
  constructor(
    @InjectRepository(Order) private readonly orders: Repository<Order>,
    @InjectRepository(Product) private readonly products: Repository<Product>,
    private readonly affiliates: AffiliatesService,
    private readonly commissions: CommissionsService,
    private readonly dataSource: DataSource,
  ) {}

  /** Crea el pedido (aún sin pagar) y guarda a qué afiliado se atribuye. */
  async create(userId: string, dto: CreateOrderDto): Promise<Order> {
    // Los precios SIEMPRE salen de la base de datos, nunca del cliente.
    const ids = [...new Set(dto.items.map((i) => i.productId))];
    const products = await this.products.findBy({ id: In(ids), active: true });
    if (products.length !== ids.length) {
      throw new BadRequestException('Algún producto no existe o no está disponible');
    }
    const byId = new Map(products.map((p) => [p.id, p]));

    const items: OrderItem[] = dto.items.map((i) => {
      const p = byId.get(i.productId)!;
      return { productId: p.id, name: p.name, unitPriceCents: p.priceCents, quantity: i.quantity };
    });
    const subtotalCents = items.reduce((sum, i) => sum + i.unitPriceCents * i.quantity, 0);

    const affiliateId = await this.affiliates.resolveForOrder(dto.affiliateCode, userId);

    return this.orders.save(
      this.orders.create({
        userId,
        items,
        subtotalCents,
        totalCents: subtotalCents,
        status: OrderStatus.PENDING,
        affiliateId,
      }),
    );
  }

  /**
   * Llámalo desde el webhook de tu pasarela cuando el pago se confirme
   * (Stripe: `checkout.session.completed` / `payment_intent.succeeded`).
   * Es idempotente: si el webhook se repite, no duplica la comisión.
   */
  async markAsPaid(orderId: string): Promise<Order> {
    return this.dataSource.transaction(async (manager) => {
      const order = await manager.findOne(Order, {
        where: { id: orderId },
        lock: { mode: 'pessimistic_write' },
      });
      if (!order) throw new NotFoundException('Pedido no encontrado');
      if (order.status === OrderStatus.PAID) return order;
      if (order.status !== OrderStatus.PENDING) {
        throw new BadRequestException(`No se puede pagar un pedido en estado ${order.status}`);
      }

      order.status = OrderStatus.PAID;
      await manager.save(order);
      await this.commissions.createForOrder(order, manager);
      return order;
    });
  }

  /** Llámalo desde el webhook de reembolso (Stripe: `charge.refunded`). */
  async refund(orderId: string): Promise<Order> {
    return this.dataSource.transaction(async (manager) => {
      const order = await manager.findOne(Order, {
        where: { id: orderId },
        lock: { mode: 'pessimistic_write' },
      });
      if (!order) throw new NotFoundException('Pedido no encontrado');
      if (order.status === OrderStatus.REFUNDED) return order;

      order.status = OrderStatus.REFUNDED;
      await manager.save(order);
      await this.commissions.reverseForOrder(order.id, manager);
      return order;
    });
  }
}
