import {
  Column,
  CreateDateColumn,
  Entity,
  Index,
  PrimaryGeneratedColumn,
} from 'typeorm';

export enum OrderStatus {
  PENDING = 'pending',
  PAID = 'paid',
  REFUNDED = 'refunded',
  CANCELLED = 'cancelled',
}

export interface OrderItem {
  productId: string;
  name: string;
  unitPriceCents: number;
  quantity: number;
}

@Entity('orders')
export class Order {
  @PrimaryGeneratedColumn('uuid')
  id!: string;

  @Index()
  @Column('uuid')
  userId!: string;

  /** Copia de los productos y precios en el momento de la compra. */
  @Column('jsonb')
  items!: OrderItem[];

  @Column('int')
  subtotalCents!: number;

  /** Subtotal + envío + impuestos (en este ejemplo, igual al subtotal). */
  @Column('int')
  totalCents!: number;

  @Column({ type: 'enum', enum: OrderStatus, default: OrderStatus.PENDING })
  status!: OrderStatus;

  /** Afiliado al que se atribuye la venta (null si llegó sin enlace). */
  @Index()
  @Column({ type: 'uuid', nullable: true })
  affiliateId!: string | null;

  @CreateDateColumn({ type: 'timestamptz' })
  createdAt!: Date;
}
