import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';

/** Producto mínimo de ejemplo. Si ya tienes tu propia entidad de productos, usa esa. */
@Entity('products')
export class Product {
  @PrimaryGeneratedColumn('uuid')
  id!: string;

  @Column()
  name!: string;

  @Column('int')
  priceCents!: number;

  @Column({ default: true })
  active!: boolean;
}
