import { CanActivate, ExecutionContext, Injectable, UnauthorizedException } from '@nestjs/common';

/**
 * ⚠️ MARCADOR DE POSICIÓN.
 * Sustitúyelo por el guard de tu sistema de autenticación, por ejemplo
 * `AuthGuard('jwt')` de @nestjs/passport. Lo único que necesita este módulo
 * es que, tras autenticar, `request.user.id` contenga el id del usuario.
 */
@Injectable()
export class JwtAuthGuard implements CanActivate {
  canActivate(context: ExecutionContext): boolean {
    const request = context.switchToHttp().getRequest<{ user?: { id?: string } }>();
    if (!request.user?.id) throw new UnauthorizedException();
    return true;
  }
}
