import { ConflictException, Injectable, NotFoundException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { InjectRepository } from '@nestjs/typeorm';
import { createHash, randomInt } from 'node:crypto';
import { Not, QueryFailedError, Repository } from 'typeorm';
import { TrackClickDto } from './dto/track-click.dto';
import { AffiliateClick } from './entities/affiliate-click.entity';
import { Affiliate, AffiliateStatus } from './entities/affiliate.entity';
import { Commission, CommissionStatus } from './entities/commission.entity';

const CODE_ALPHABET = 'abcdefghjkmnpqrstuvwxyz23456789'; // sin 0/o/1/l/i para que no se confundan
const CODE_LENGTH = 8;

function generateCode(): string {
  let code = '';
  for (let i = 0; i < CODE_LENGTH; i++) {
    code += CODE_ALPHABET[randomInt(CODE_ALPHABET.length)];
  }
  return code;
}

function isUniqueViolation(err: unknown): boolean {
  return (
    err instanceof QueryFailedError &&
    (err as QueryFailedError & { driverError?: { code?: string } }).driverError?.code === '23505'
  );
}

export interface AffiliateStats {
  code: string;
  commissionPercent: number;
  status: AffiliateStatus;
  clicks: number;
  conversions: number;
  conversionRate: number;
  pendingCents: number;
  approvedCents: number;
  paidCents: number;
}

@Injectable()
export class AffiliatesService {
  constructor(
    @InjectRepository(Affiliate) private readonly affiliates: Repository<Affiliate>,
    @InjectRepository(AffiliateClick) private readonly clicks: Repository<AffiliateClick>,
    @InjectRepository(Commission) private readonly commissions: Repository<Commission>,
    private readonly config: ConfigService,
  ) {}

  /** Da de alta al usuario como afiliado (o devuelve el existente). */
  async join(userId: string): Promise<Affiliate> {
    const existing = await this.affiliates.findOneBy({ userId });
    if (existing) return existing;

    const commissionBps = Number(this.config.get('AFFILIATE_DEFAULT_BPS') ?? 1000);

    for (let attempt = 0; attempt < 5; attempt++) {
      try {
        return await this.affiliates.save(
          this.affiliates.create({ userId, code: generateCode(), commissionBps }),
        );
      } catch (err) {
        if (!isUniqueViolation(err)) throw err;
        // Colisión: o el código ya existía (reintentamos) o el usuario se dio de alta
        // en paralelo (devolvemos el que se creó).
        const created = await this.affiliates.findOneBy({ userId });
        if (created) return created;
      }
    }
    throw new ConflictException('No se pudo generar un código de afiliado único');
  }

  findActiveByCode(code: string): Promise<Affiliate | null> {
    return this.affiliates.findOneBy({
      code: code.toLowerCase(),
      status: AffiliateStatus.ACTIVE,
    });
  }

  /** Registra una visita con ?ref=. Devuelve si el código es válido. */
  async trackClick(dto: TrackClickDto): Promise<{ valid: boolean }> {
    const affiliate = await this.findActiveByCode(dto.code);
    if (!affiliate) return { valid: false };

    await this.clicks.insert({
      affiliateId: affiliate.id,
      ipHash: dto.ip ? this.hashIp(dto.ip) : null,
      userAgent: dto.userAgent ?? null,
      landingPath: dto.landingPath ?? null,
    });
    return { valid: true };
  }

  /**
   * Decide a qué afiliado se atribuye un pedido.
   * Devuelve null si no hay código, no es válido o el comprador es el propio afiliado.
   */
  async resolveForOrder(code: string | undefined, buyerUserId: string): Promise<string | null> {
    if (!code) return null;
    const affiliate = await this.findActiveByCode(code);
    if (!affiliate) return null;
    if (affiliate.userId === buyerUserId) return null; // auto-referido: no cuenta
    return affiliate.id;
  }

  async getStats(userId: string): Promise<AffiliateStats> {
    const affiliate = await this.affiliates.findOneBy({ userId });
    if (!affiliate) throw new NotFoundException('No eres afiliado todavía');

    const [clicks, conversions, rows] = await Promise.all([
      this.clicks.countBy({ affiliateId: affiliate.id }),
      this.commissions.countBy({
        affiliateId: affiliate.id,
        status: Not(CommissionStatus.REJECTED),
      }),
      this.commissions
        .createQueryBuilder('c')
        .select('c.status', 'status')
        .addSelect('COALESCE(SUM(c.amountCents), 0)', 'total')
        .where('c.affiliateId = :id', { id: affiliate.id })
        .groupBy('c.status')
        .getRawMany<{ status: CommissionStatus; total: string }>(),
    ]);

    const totalBy = (status: CommissionStatus) =>
      Number(rows.find((r) => r.status === status)?.total ?? 0);

    return {
      code: affiliate.code,
      commissionPercent: affiliate.commissionBps / 100,
      status: affiliate.status,
      clicks,
      conversions,
      conversionRate: clicks > 0 ? conversions / clicks : 0,
      pendingCents: totalBy(CommissionStatus.PENDING),
      approvedCents: totalBy(CommissionStatus.APPROVED),
      paidCents: totalBy(CommissionStatus.PAID),
    };
  }

  private hashIp(ip: string): string {
    const salt = this.config.get<string>('IP_HASH_SALT') ?? '';
    return createHash('sha256').update(salt + ip).digest('hex');
  }
}
