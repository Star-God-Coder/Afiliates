import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AffiliatesController } from './affiliates.controller';
import { AffiliatesService } from './affiliates.service';
import { CommissionsService } from './commissions.service';
import { AffiliateClick } from './entities/affiliate-click.entity';
import { Affiliate } from './entities/affiliate.entity';
import { Commission } from './entities/commission.entity';

@Module({
  imports: [TypeOrmModule.forFeature([Affiliate, AffiliateClick, Commission])],
  controllers: [AffiliatesController],
  providers: [AffiliatesService, CommissionsService],
  exports: [AffiliatesService, CommissionsService],
})
export class AffiliatesModule {}
