import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Cron, CronExpression } from '@nestjs/schedule';
import { InjectRepository } from '@nestjs/typeorm';
import { EntityManager, In, LessThanOrEqual, Repository } from 'typeorm';
import type { Order } from '../orders/entities/order.entity';
import { Affiliate, AffiliateStatus } from './entities/affiliate.entity';
import { Commission, CommissionStatus } from './entities/commission.entity';

const DAY_MS = 24 * 60 * 60 * 1000;

@Injectable()
export class CommissionsService {
  private readonly logger = new Logger(CommissionsService.name);

  constructor(
    @InjectRepository(Commission) private readonly commissions: Repository<Commission>,
    private readonly config: ConfigService,
  ) {}

  /**
   * Crea la comisión de un pedido YA PAGADO. Es idempotente: si el webhook de pago
   * llega dos veces, la restricción única en orderId evita duplicados.
   * Pásale el `manager` de la transacción para que todo se guarde junto.
   */
  async createForOrder(order: Order, manager?: EntityManager): Promise<void> {
    if (!order.affiliateId) return;

    const em = manager ?? this.commissions.manager;
    const affiliate = await em.findOneBy(Affiliate, { id: order.affiliateId });
    if (!affiliate || affiliate.status !== AffiliateStatus.ACTIVE) return;

    // Comisión sobre el subtotal (sin envío ni impuestos). Redondeo hacia abajo.
    const baseCents = order.subtotalCents;
    const amountCents = Math.floor((baseCents * affiliate.commissionBps) / 10_000);
    if (amountCents <= 0) return;

    const holdDays = Number(this.config.get('AFFILIATE_HOLD_DAYS') ?? 30);

    await em
      .createQueryBuilder()
      .insert()
      .into(Commission)
      .values({
        affiliateId: affiliate.id,
        orderId: order.id,
        baseCents,
        rateBps: affiliate.commissionBps,
        amountCents,
        status: CommissionStatus.PENDING,
        availableAt: new Date(Date.now() + holdDays * DAY_MS),
      })
      .orIgnore()
      .execute();
  }

  /** Pedido reembolsado/cancelado: anula la comisión si aún no se pagó. */
  async reverseForOrder(orderId: string, manager?: EntityManager): Promise<void> {
    const repo = manager ? manager.getRepository(Commission) : this.commissions;
    const commission = await repo.findOneBy({ orderId });
    if (!commission) return;

    if (commission.status === CommissionStatus.PAID) {
      // Ya se pagó: no lo tocamos automáticamente. Descuéntalo del próximo pago a mano
      // o crea aquí tu lógica de "clawback".
      this.logger.warn(`Pedido ${orderId} reembolsado con comisión ya pagada (${commission.id})`);
      return;
    }
    await repo.update(
      { id: commission.id, status: In([CommissionStatus.PENDING, CommissionStatus.APPROVED]) },
      { status: CommissionStatus.REJECTED },
    );
  }

  /** Cada hora, aprueba las comisiones que ya superaron el periodo de devoluciones. */
  @Cron(CronExpression.EVERY_HOUR)
  async approveMatured(): Promise<void> {
    const result = await this.commissions.update(
      { status: CommissionStatus.PENDING, availableAt: LessThanOrEqual(new Date()) },
      { status: CommissionStatus.APPROVED },
    );
    if (result.affected) this.logger.log(`${result.affected} comisiones aprobadas`);
  }

  /** Marca como pagadas las comisiones aprobadas (llámalo desde tu panel de admin al pagar). */
  async markPaidOut(commissionIds: string[]): Promise<number> {
    if (commissionIds.length === 0) return 0;
    const result = await this.commissions.update(
      { id: In(commissionIds), status: CommissionStatus.APPROVED },
      { status: CommissionStatus.PAID, paidAt: new Date() },
    );
    return result.affected ?? 0;
  }
}
