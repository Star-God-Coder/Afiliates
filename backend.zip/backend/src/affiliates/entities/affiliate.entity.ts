import {
  Column,
  CreateDateColumn,
  Entity,
  Index,
  PrimaryGeneratedColumn,
} from 'typeorm';

export enum AffiliateStatus {
  ACTIVE = 'active',
  SUSPENDED = 'suspended',
}

@Entity('affiliates')
export class Affiliate {
  @PrimaryGeneratedColumn('uuid')
  id!: string;

  /** Usuario de tu sistema que es dueño de este enlace (un afiliado por usuario). */
  @Index({ unique: true })
  @Column('uuid')
  userId!: string;

  /** Código que va en el enlace: tusitio.com/?ref=<code> */
  @Index({ unique: true })
  @Column({ length: 32 })
  code!: string;

  /**
   * Comisión en "basis points" para evitar decimales:
   * 1000 = 10 %, 250 = 2,5 %, 10000 = 100 %.
   */
  @Column('int', { default: 1000 })
  commissionBps!: number;

  @Column({ type: 'enum', enum: AffiliateStatus, default: AffiliateStatus.ACTIVE })
  status!: AffiliateStatus;

  @CreateDateColumn({ type: 'timestamptz' })
  createdAt!: Date;
}
