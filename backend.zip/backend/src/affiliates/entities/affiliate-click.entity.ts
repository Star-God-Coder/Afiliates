import {
  Column,
  CreateDateColumn,
  Entity,
  Index,
  PrimaryGeneratedColumn,
} from 'typeorm';

/** Cada visita que llega con ?ref=<code>. Sirve para estadísticas (tasa de conversión). */
@Entity('affiliate_clicks')
export class AffiliateClick {
  @PrimaryGeneratedColumn('uuid')
  id!: string;

  @Index()
  @Column('uuid')
  affiliateId!: string;

  /** Hash de la IP (no guardamos la IP en claro por privacidad). */
  @Column({ type: 'varchar', length: 64, nullable: true })
  ipHash!: string | null;

  @Column({ type: 'varchar', length: 512, nullable: true })
  userAgent!: string | null;

  @Column({ type: 'varchar', length: 512, nullable: true })
  landingPath!: string | null;

  @CreateDateColumn({ type: 'timestamptz' })
  createdAt!: Date;
}
