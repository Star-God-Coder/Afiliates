import {
  Column,
  CreateDateColumn,
  Entity,
  Index,
  PrimaryGeneratedColumn,
} from 'typeorm';

export enum CommissionStatus {
  /** Venta pagada, pero aún dentro del periodo de devoluciones. */
  PENDING = 'pending',
  /** Pasó el periodo de espera: ya se le debe al afiliado. */
  APPROVED = 'approved',
  /** Ya se le pagó al afiliado. */
  PAID = 'paid',
  /** Pedido reembolsado o cancelado: no se paga. */
  REJECTED = 'rejected',
}

@Entity('commissions')
export class Commission {
  @PrimaryGeneratedColumn('uuid')
  id!: string;

  @Index()
  @Column('uuid')
  affiliateId!: string;

  /** Único: un pedido genera como máximo una comisión (protege contra webhooks repetidos). */
  @Index({ unique: true })
  @Column('uuid')
  orderId!: string;

  /** Importe sobre el que se calculó la comisión, en céntimos. */
  @Column('int')
  baseCents!: number;

  /** Porcentaje aplicado en ese momento (copia; si luego cambias la tasa del afiliado, el histórico no cambia). */
  @Column('int')
  rateBps!: number;

  /** Comisión a pagar, en céntimos. */
  @Column('int')
  amountCents!: number;

  @Index()
  @Column({ type: 'enum', enum: CommissionStatus, default: CommissionStatus.PENDING })
  status!: CommissionStatus;

  /** Fecha a partir de la cual la comisión pasa de PENDING a APPROVED. */
  @Column({ type: 'timestamptz' })
  availableAt!: Date;

  @Column({ type: 'timestamptz', nullable: true })
  paidAt!: Date | null;

  @CreateDateColumn({ type: 'timestamptz' })
  createdAt!: Date;
}
