import { IsOptional, IsString, Matches, MaxLength } from 'class-validator';

export const AFFILIATE_CODE_REGEX = /^[a-z0-9_-]{3,32}$/i;

export class TrackClickDto {
  @IsString()
  @Matches(AFFILIATE_CODE_REGEX)
  code!: string;

  @IsOptional()
  @IsString()
  @MaxLength(512)
  landingPath?: string;

  /** IP del visitante; la reenvía el proxy de Next.js. */
  @IsOptional()
  @IsString()
  @MaxLength(64)
  ip?: string;

  @IsOptional()
  @IsString()
  @MaxLength(512)
  userAgent?: string;
}
