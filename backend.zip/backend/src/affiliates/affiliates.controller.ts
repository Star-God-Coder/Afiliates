import { Body, Controller, Get, HttpCode, Post, UseGuards } from '@nestjs/common';
import { CurrentUser, type AuthUser } from '../auth/current-user.decorator';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { AffiliatesService } from './affiliates.service';
import { TrackClickDto } from './dto/track-click.dto';

@Controller('affiliates')
export class AffiliatesController {
  constructor(private readonly affiliates: AffiliatesService) {}

  /** Público: lo llama el proxy de Next.js cuando alguien entra con ?ref=. */
  @Post('clicks')
  @HttpCode(200)
  trackClick(@Body() dto: TrackClickDto) {
    return this.affiliates.trackClick(dto);
  }

  /** El usuario logueado se une al programa y obtiene su código. */
  @Post('me')
  @UseGuards(JwtAuthGuard)
  async join(@CurrentUser() user: AuthUser) {
    const affiliate = await this.affiliates.join(user.id);
    return { code: affiliate.code, commissionPercent: affiliate.commissionBps / 100 };
  }

  /** Estadísticas del afiliado logueado (404 si aún no es afiliado). */
  @Get('me')
  @UseGuards(JwtAuthGuard)
  stats(@CurrentUser() user: AuthUser) {
    return this.affiliates.getStats(user.id);
  }
}
